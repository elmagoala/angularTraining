import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';

import { AppComponent } from './app.component';
import { NgNavbarComponent } from './components/ng-navbar/ng-navbar.component';
import { NgMenuComponent } from './components/ng-menu/ng-menu.component';
import { NgProductoComponent } from './components/ng-producto/ng-producto.component';
import { AppRoutingModule } from './app-routing.module';
import { CategoriaService } from './services/categoria.service';

@NgModule({
  declarations: [
    AppComponent,
    NgNavbarComponent,
    NgMenuComponent,
    NgProductoComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule.forRoot()
  ],
  providers: [CategoriaService],
  bootstrap: [AppComponent]
})
export class AppModule { }
