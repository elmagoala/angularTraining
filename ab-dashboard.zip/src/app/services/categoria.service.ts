import { Injectable } from '@angular/core';

import { Categoria } from 'app/models/categoria';
import { CATEGORIAS } from 'app/mocks/categoria.mock';

@Injectable()
export class CategoriaService {
    getCategorias():Categoria[] {
        return CATEGORIAS;
    }
}