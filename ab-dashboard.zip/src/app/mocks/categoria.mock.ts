import { Categoria } from 'app/models/categoria';

export const CATEGORIAS: Categoria[] = [
    {id:1, descripcion:'Limpieza'},
    {id:2, descripcion:'Otros'},
];