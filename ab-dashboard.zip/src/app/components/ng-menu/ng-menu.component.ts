import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ng-menu',
  templateUrl: './ng-menu.component.html',
  styleUrls: ['./ng-menu.component.css']
})
export class NgMenuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
