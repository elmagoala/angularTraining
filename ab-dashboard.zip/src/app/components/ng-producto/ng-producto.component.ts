import { Component, OnInit } from '@angular/core';
import { CategoriaService } from 'app/services/categoria.service';
import { Categoria } from 'app/models/categoria';

@Component({
  selector: 'ng-producto',
  templateUrl: './ng-producto.component.html',
  styleUrls: ['./ng-producto.component.css']
})
export class NgProductoComponent implements OnInit {

  categorias : Categoria[] = [];

  constructor(private categoriaService: CategoriaService) { }

  getCategorias(): void {
    this.categorias = this.categoriaService.getCategorias();
  }

  ngOnInit() {
     this.getCategorias();
  }

}
