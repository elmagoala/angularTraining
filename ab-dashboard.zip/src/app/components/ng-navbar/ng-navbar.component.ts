import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ng-navbar',
  templateUrl: './ng-navbar.component.html',
  styleUrls: ['./ng-navbar.component.css']
})
export class NgNavbarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
