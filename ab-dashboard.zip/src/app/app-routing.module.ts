import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { NgProductoComponent } from 'app/components/ng-producto/ng-producto.component';

const routes: Routes = [
  {
    path: 'producto',
    component: NgProductoComponent,
    children: []
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}