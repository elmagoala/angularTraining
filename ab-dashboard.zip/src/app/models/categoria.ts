export class Categoria {
    id: number;
    descripcion: string;
}